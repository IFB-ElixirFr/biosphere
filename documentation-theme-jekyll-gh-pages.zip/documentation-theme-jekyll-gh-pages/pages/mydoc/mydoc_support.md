---
title: Support
tags: [getting_started, troubleshooting]
keywords: questions, troubleshooting, contact, support
last_updated: July 3, 2016
summary: "Contact me for any support issues."
sidebar: mydoc_sidebar
permalink: mydoc_support.html
folder: mydoc
topnav: topnav
---

I'm not actively working on this theme. However, feel free to click **Feedback** on the top navbar to send me an email or open an issue on [GitHub](https://github.com/tomjoht/documentation-theme-jekyll/issues).
