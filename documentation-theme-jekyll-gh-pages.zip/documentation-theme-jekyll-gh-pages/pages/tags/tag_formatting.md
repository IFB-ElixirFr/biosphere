---
title: "Formatting pages"
tagName: formatting
search: exclude
permalink: tag_formatting.html
sidebar: mydoc_sidebar
folder: tags
---
{% include taglogic.html %}

{% include links.html %}
